Add to classpath before using: 
- lib/colt.jar
- lib/concurrent.jar
- lib/commons-logging-1.2.jar
- lib/commons-math3-3.4.1.jar
- lib/commons-math-2.2-sources.jar
- gurobi.jar (install before using academic license)